package sptech.project04;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project04ApplicationTests {

	@Test
	void contextLoads() {
	}

}
